package org.emely.act1;

import jakarta.persistence.EntityManager;
import org.emely.act1.entity.Groups;
import org.emely.act1.entity.Student;
import org.emely.act1.util.JpaUtil;


public class Main {
    public static void main(String[] args) {

        EntityManager em = JpaUtil.getEntityManager();

        try {
            em.getTransaction().begin();

            Student student = new Student("Emely", "Lazo");
            em.persist(student);
            em.getTransaction().commit();
            System.out.println(student);

            /*Groups gruop = new Groups("Fisica");
            gruop.setId(1L);
            em.persist(gruop);
            em.getTransaction().commit();
            System.out.println(gruop);
*/
            /*Teacher teacher = new Teacher("josue", "Castillo");
            em.persist(teacher);
            em.getTransaction().commit();
            System.out.println(teacher);*/

            System.out.println("hola xd");
        } catch (Exception e) {
            em.getTransaction().rollback();

        } finally {
            em.close();
        }


    }
}