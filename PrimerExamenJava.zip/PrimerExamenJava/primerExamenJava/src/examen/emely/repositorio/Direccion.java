package examen.emely.repositorio;

public enum Direccion {
    ASC, DESC;
}
