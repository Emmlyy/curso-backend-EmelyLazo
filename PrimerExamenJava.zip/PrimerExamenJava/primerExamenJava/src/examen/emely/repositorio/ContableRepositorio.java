package examen.emely.repositorio;

public interface ContableRepositorio{
    int total();
}
